# Puran Paodensakul
# 6611140
# 541

def min_coin_change(coins, amount):
    """
    Calculates the minimum number of coins required to make a certain amount
    using dynamic programming.
    """
    # Initialize DP table with a value larger than any possible number of coins
    dp = [float('inf')] * (amount + 1)
    
    # Base case: 0 coins are needed to make an amount of 0
    dp[0] = 0
    
    # Iterate through all amounts from 1 to the target amount
    for i in range(1, amount + 1):
        # For each amount, iterate through all coin denominations
        for coin in coins:
            if i >= coin:
                dp[i] = min(dp[i], dp[i - coin] + 1)
                
    # If dp[amount] is still infinity, it means the amount cannot be made
    return dp[amount] if dp[amount] != float('inf') else -1

if __name__ == '__main__':
    coins_input = list(map(int, input().split()))
    amount_input = int(input())
    
    result = min_coin_change(coins_input, amount_input)
    print(result)
